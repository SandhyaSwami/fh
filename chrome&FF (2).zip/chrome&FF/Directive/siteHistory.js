/**
 * Created by vaibhav_parkhi on 5/23/2017.
 */
location_macro.directive("siteBackButton",function(){

    return{
        restrict:'A',
        link:function(scope,element,attrs){
            element.on("click",function(){
                console.log(window.top);
                window.top.history.back();
            })
        }

    }
});
location_macro.directive("siteNextButton",function(){

    return{
        restrict:'A',
        link:function(scope,element,attrs){
            element.on("click",function(){
                window.top.history.forward();
            })
        }

    }
});